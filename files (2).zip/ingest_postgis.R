# Daily ingestion into PostGIS (replacement for ingest.R once you have migrated).
library(DBI)
library(RPostgres)
source("openmeteo.R")

pg <- dbConnect(Postgres(), host = "localhost", dbname = "weather",
                user = "weather", password = Sys.getenv("PGPASSWORD", "weather"))

st <- dbGetQuery(pg, "SELECT station_id, name, ST_Y(geom) AS lat, ST_X(geom) AS lon FROM stations")

for (i in seq_len(nrow(st))) {
  df <- tryCatch(
    fetch_open_meteo(st$station_id[i], st$lat[i], st$lon[i],
                     "https://api.open-meteo.com/v1/forecast",
                     past_days = 2, forecast_days = 1),
    error = function(e) { message("FAILED ", st$name[i], ": ", conditionMessage(e)); NULL }
  )
  if (is.null(df)) next
  df$ts <- as.POSIXct(df$ts, format = "%Y-%m-%dT%H:%M", tz = "UTC")

  n <- dbExecute(
    pg,
    "INSERT INTO readings (station_id, ts, temperature_c, precip_mm, wind_kmh)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (station_id, ts) DO UPDATE SET
       temperature_c = EXCLUDED.temperature_c,
       precip_mm     = EXCLUDED.precip_mm,
       wind_kmh      = EXCLUDED.wind_kmh",
    params = unname(as.list(df))
  )
  message(st$name[i], ": ", n, " rows upserted")
}
dbDisconnect(pg)
