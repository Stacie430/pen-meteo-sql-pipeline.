# Copies stations and readings from wetter.sqlite into PostgreSQL/PostGIS.
# Start the database first:  docker compose up -d
# install.packages(c("DBI", "RSQLite", "RPostgres"))
library(DBI)
library(RSQLite)
library(RPostgres)

lite <- dbConnect(SQLite(), "wetter.sqlite")
pg   <- dbConnect(Postgres(), host = "localhost", dbname = "weather",
                  user = "weather", password = Sys.getenv("PGPASSWORD", "weather"))

# 1. Schema
sql <- paste(readLines("schema_postgis.sql"), collapse = "\n")
for (stmt in strsplit(sql, ";\\s*\n")[[1]]) {
  if (nzchar(trimws(stmt))) dbExecute(pg, stmt)
}

# 2. Stations (keep the same ids so readings still match)
st <- dbGetQuery(lite, "SELECT station_id, name, lat, lon FROM stations")
dbExecute(
  pg,
  "INSERT INTO stations (station_id, name, geom)
   VALUES ($1, $2, ST_SetSRID(ST_MakePoint($3, $4), 4326))
   ON CONFLICT (name) DO NOTHING",
  params = list(st$station_id, st$name, st$lon, st$lat)   # note: lon first
)
dbExecute(pg, "SELECT setval(pg_get_serial_sequence('stations','station_id'),
                             (SELECT MAX(station_id) FROM stations))")

# 3. Readings in chunks
r <- dbGetQuery(lite, "SELECT * FROM readings")
r$ts <- as.POSIXct(r$ts, format = "%Y-%m-%dT%H:%M", tz = "UTC")
chunks <- split(r, ceiling(seq_len(nrow(r)) / 5000))
for (ch in chunks) {
  dbExecute(
    pg,
    "INSERT INTO readings (station_id, ts, temperature_c, precip_mm, wind_kmh)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (station_id, ts) DO NOTHING",
    params = unname(as.list(ch))
  )
}
message("Migrated ", nrow(r), " readings")

dbDisconnect(lite); dbDisconnect(pg)
