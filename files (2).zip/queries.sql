-- 1) 7-day moving average of daily temperature
SELECT station_id, day, avg_temp,
       ROUND(AVG(avg_temp) OVER (
         PARTITION BY station_id ORDER BY day
         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 2) AS ma_7d
FROM daily_stats;

-- 2) Warmest station per day
SELECT day, name, avg_temp
FROM (
  SELECT d.day, s.name, d.avg_temp,
         RANK() OVER (PARTITION BY d.day ORDER BY d.avg_temp DESC) AS rnk
  FROM daily_stats d JOIN stations s USING (station_id)
)
WHERE rnk = 1;

-- 3) Anomalies: hourly readings > 2 standard deviations from the station mean
WITH stats AS (
  SELECT station_id,
         AVG(temperature_c) AS mu,
         SQRT(AVG(temperature_c * temperature_c) - AVG(temperature_c) * AVG(temperature_c)) AS sigma
  FROM readings GROUP BY station_id
)
SELECT r.station_id, r.ts, r.temperature_c,
       ROUND((r.temperature_c - s.mu) / s.sigma, 2) AS z_score
FROM readings r JOIN stats s USING (station_id)
WHERE s.sigma > 0 AND ABS(r.temperature_c - s.mu) > 2 * s.sigma
ORDER BY ABS(z_score) DESC;

-- 4) Warmest and coldest days relative to climate (needs backfilled data)
SELECT s.name, a.day, a.avg_temp, a.clim_temp, a.temp_anomaly
FROM daily_anomaly a JOIN stations s USING (station_id)
ORDER BY ABS(a.temp_anomaly) DESC
LIMIT 20;

-- 5) Hour-to-hour temperature change with LAG
SELECT station_id, ts, temperature_c,
       ROUND(temperature_c - LAG(temperature_c) OVER (
         PARTITION BY station_id ORDER BY ts), 2) AS delta_1h
FROM readings;

-- 6) Missing hours: gaps in the time series
SELECT station_id, ts AS gap_after, next_ts
FROM (
  SELECT station_id, ts,
         LEAD(ts) OVER (PARTITION BY station_id ORDER BY ts) AS next_ts
  FROM readings
)
WHERE next_ts IS NOT NULL
  AND (julianday(next_ts) - julianday(ts)) * 24 > 1.01;
