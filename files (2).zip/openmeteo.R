library(httr2)

# Returns a data.frame with one row per hour for the given station.
# base_url: forecast API for recent data, archive API for history.
fetch_open_meteo <- function(station_id, lat, lon, base_url, ...) {
  resp <- request(base_url) |>
    req_url_query(
      latitude = lat, longitude = lon,
      hourly = "temperature_2m,precipitation,wind_speed_10m",
      timezone = "UTC", ...
    ) |>
    req_retry(max_tries = 3) |>
    req_perform() |>
    resp_body_json()

  num <- function(x) vapply(x, function(v) if (is.null(v)) NA_real_ else v, numeric(1))
  h <- resp$hourly
  data.frame(
    station_id    = station_id,
    ts            = unlist(h$time),
    temperature_c = num(h$temperature_2m),
    precip_mm     = num(h$precipitation),
    wind_kmh      = num(h$wind_speed_10m)
  )
}
