PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS stations (
  station_id INTEGER PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE,
  lat        REAL NOT NULL,
  lon        REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS readings (
  station_id    INTEGER NOT NULL REFERENCES stations(station_id),
  ts            TEXT    NOT NULL,          -- ISO 8601, UTC
  temperature_c REAL,
  precip_mm     REAL,
  wind_kmh      REAL,
  PRIMARY KEY (station_id, ts)             -- prevents duplicates on reruns
);

CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings(ts);

CREATE VIEW IF NOT EXISTS daily_stats AS
SELECT station_id,
       date(ts)            AS day,
       ROUND(AVG(temperature_c), 2) AS avg_temp,
       MIN(temperature_c)  AS min_temp,
       MAX(temperature_c)  AS max_temp,
       ROUND(SUM(precip_mm), 2)     AS total_precip
FROM readings
GROUP BY station_id, date(ts);

-- Long-term monthly mean per station (the "normal" for each calendar month)
CREATE VIEW IF NOT EXISTS monthly_climatology AS
SELECT station_id,
       CAST(strftime('%m', day) AS INTEGER) AS month,
       ROUND(AVG(avg_temp), 2)              AS clim_temp,
       ROUND(AVG(total_precip), 2)          AS clim_precip,
       COUNT(DISTINCT strftime('%Y', day))  AS n_years
FROM daily_stats
GROUP BY station_id, CAST(strftime('%m', day) AS INTEGER);

-- Each day compared with its station's climatology for that month
CREATE VIEW IF NOT EXISTS daily_anomaly AS
SELECT d.station_id, d.day, d.avg_temp, c.clim_temp,
       ROUND(d.avg_temp - c.clim_temp, 2) AS temp_anomaly
FROM daily_stats d
JOIN monthly_climatology c
  ON c.station_id = d.station_id
 AND c.month = CAST(strftime('%m', d.day) AS INTEGER);
