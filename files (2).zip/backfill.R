# One-off: load several years of history into wetter.sqlite.
# Run ingest.R once first (it creates the database and the stations).
library(DBI)
library(RSQLite)
source("openmeteo.R")

START_YEAR <- 2020
archive_url <- "https://archive-api.open-meteo.com/v1/archive"

con <- dbConnect(SQLite(), "wetter.sqlite")
st  <- dbGetQuery(con, "SELECT station_id, name, lat, lon FROM stations")

# The archive lags a few days behind, so stop a week ago
end_all <- Sys.Date() - 7

for (i in seq_len(nrow(st))) {
  for (yr in START_YEAR:as.integer(format(end_all, "%Y"))) {
    start <- as.Date(sprintf("%d-01-01", yr))
    end   <- min(as.Date(sprintf("%d-12-31", yr)), end_all)

    df <- tryCatch(
      fetch_open_meteo(st$station_id[i], st$lat[i], st$lon[i], archive_url,
                       start_date = format(start), end_date = format(end)),
      error = function(e) { message("FAILED ", st$name[i], " ", yr, ": ", conditionMessage(e)); NULL }
    )
    if (is.null(df)) next

    dbExecute(
      con,
      "INSERT INTO readings (station_id, ts, temperature_c, precip_mm, wind_kmh)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(station_id, ts) DO NOTHING",
      params = unname(as.list(df))
    )
    message(st$name[i], " ", yr, ": ", nrow(df), " hours")
    Sys.sleep(1)   # be polite to the free API
  }
}

dbDisconnect(con)
