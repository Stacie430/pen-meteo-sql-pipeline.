-- PostGIS examples (coordinates are lon, lat in SRID 4326)

-- 1) Distance matrix between stations in km
SELECT a.name AS from_station, b.name AS to_station,
       ROUND((ST_Distance(a.geom::geography, b.geom::geography) / 1000)::numeric, 1) AS km
FROM stations a JOIN stations b ON a.station_id < b.station_id
ORDER BY km;

-- 2) Nearest station to a point (here: Münster city centre), using the GiST index
SELECT name,
       ROUND((ST_Distance(geom::geography,
              ST_SetSRID(ST_MakePoint(7.63, 51.96), 4326)::geography) / 1000)::numeric, 1) AS km
FROM stations
ORDER BY geom <-> ST_SetSRID(ST_MakePoint(7.63, 51.96), 4326)
LIMIT 1;

-- 3) Average temperature of all stations within 300 km of a point, per day
SELECT d.day, ROUND(AVG(d.avg_temp), 2) AS avg_temp_300km
FROM daily_stats d
JOIN stations s USING (station_id)
WHERE ST_DWithin(s.geom::geography,
                 ST_SetSRID(ST_MakePoint(7.63, 51.96), 4326)::geography, 300000)
GROUP BY d.day
ORDER BY d.day;

-- 4) Inverse-distance-weighted (IDW) temperature at any point, latest reading per station
--    (point must not coincide exactly with a station, otherwise distance = 0)
WITH latest AS (
  SELECT DISTINCT ON (station_id) station_id, temperature_c
  FROM readings
  WHERE temperature_c IS NOT NULL
  ORDER BY station_id, ts DESC
),
pt AS (SELECT ST_SetSRID(ST_MakePoint(8.5, 51.0), 4326)::geography AS g)
SELECT ROUND((SUM(l.temperature_c / POWER(ST_Distance(s.geom::geography, pt.g), 2))
            / SUM(1 / POWER(ST_Distance(s.geom::geography, pt.g), 2)))::numeric, 2) AS idw_temp
FROM latest l JOIN stations s USING (station_id), pt;
