CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS stations (
  station_id SERIAL PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE,
  geom       geometry(Point, 4326) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_stations_geom ON stations USING GIST (geom);

CREATE TABLE IF NOT EXISTS readings (
  station_id    INTEGER NOT NULL REFERENCES stations(station_id),
  ts            TIMESTAMPTZ NOT NULL,
  temperature_c DOUBLE PRECISION,
  precip_mm     DOUBLE PRECISION,
  wind_kmh      DOUBLE PRECISION,
  PRIMARY KEY (station_id, ts)
);
CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings (ts);

CREATE OR REPLACE VIEW daily_stats AS
SELECT station_id,
       (ts AT TIME ZONE 'UTC')::date AS day,
       ROUND(AVG(temperature_c)::numeric, 2) AS avg_temp,
       MIN(temperature_c) AS min_temp,
       MAX(temperature_c) AS max_temp,
       ROUND(SUM(precip_mm)::numeric, 2) AS total_precip
FROM readings
GROUP BY station_id, (ts AT TIME ZONE 'UTC')::date;

CREATE OR REPLACE VIEW monthly_climatology AS
SELECT station_id,
       EXTRACT(MONTH FROM day)::int AS month,
       ROUND(AVG(avg_temp), 2)      AS clim_temp,
       COUNT(DISTINCT EXTRACT(YEAR FROM day)) AS n_years
FROM daily_stats
GROUP BY station_id, EXTRACT(MONTH FROM day);

CREATE OR REPLACE VIEW daily_anomaly AS
SELECT d.station_id, d.day, d.avg_temp, c.clim_temp,
       ROUND(d.avg_temp - c.clim_temp, 2) AS temp_anomaly
FROM daily_stats d
JOIN monthly_climatology c
  ON c.station_id = d.station_id
 AND c.month = EXTRACT(MONTH FROM d.day)::int;
